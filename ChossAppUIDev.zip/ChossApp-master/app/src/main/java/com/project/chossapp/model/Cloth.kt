package com.project.chossapp.model

data class Cloth(
    val name: String? = null
)