package com.project.chossapp.ui.mycloth

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.GridLayoutManager
import com.project.chossapp.databinding.FragmentMyClothBinding
import com.project.chossapp.model.Cloth
import com.project.chossapp.ui.mycloth.adapter.MyClothAdapter

class MyClothFragment : Fragment() {

    private var _binding: FragmentMyClothBinding? = null
    private val binding get() = _binding!!
    private val myClothAdapter by lazy { MyClothAdapter() }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentMyClothBinding.inflate(inflater)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        setupRecyclerView()
    }

    private fun setupRecyclerView() {
        binding.rvMyCloth.apply {
            adapter = myClothAdapter
            layoutManager = GridLayoutManager(requireContext(), 2)
        }

        val listClothDummy = mutableListOf<Cloth>()
        for (i in 1..10) {
            val cloth = Cloth("White Dress")
            listClothDummy.add(cloth)
        }

        myClothAdapter.differ.submitList(listClothDummy)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

}