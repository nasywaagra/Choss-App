package com.project.chossapp.ui.recommendation

import android.os.Build
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.project.chossapp.databinding.ActivityDetailRecommendationBinding
import com.project.chossapp.util.Clothes
import com.project.chossapp.util.Dimen
import com.project.chossapp.util.hide
import com.project.chossapp.util.toast
import com.project.chossapp.util.visible

@Suppress("DEPRECATION")
class DetailRecommendationActivity : AppCompatActivity() {

    private var _binding: ActivityDetailRecommendationBinding? = null
    private val binding get() = _binding!!
    private var clothes: Clothes? = null
    private var color: Int? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        _binding = ActivityDetailRecommendationBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupPage()
        setColorAction()

        binding.btnBack.setOnClickListener {
            finish()
        }
    }

    private fun setColorAction() {

    }

    private fun setupPage() {
        val data = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            intent.getParcelableExtra(Dimen.CLOTH, Clothes::class.java)
        } else {
            intent.getParcelableExtra(Dimen.CLOTH)
        }

        val index = intent.getIntExtra("index", 0)

        data?.let { clothes1 ->
            clothes = clothes1
            with(binding) {
                ivCloth.setImageResource(clothes1.photos!![index-1])
                tvClothName.text = clothes1.name
                tvColorTemperature.text = clothes1.colorTemperature

                cvColor1.setOnClickListener {
                    checkHandling(1)
                    color = it.solidColor
                    toast(color.toString())
                }
                cvColor2.setOnClickListener {
                    checkHandling(2)
                    color = it.solidColor
                    toast(color.toString())
                }
                cvColor3.setOnClickListener {
                    checkHandling(3)
                    color = it.solidColor
                    toast(color.toString())
                }
                cvColor4.setOnClickListener {
                    checkHandling(4)
                    color = it.solidColor
                    toast(color.toString())
                }
                cvColor5.setOnClickListener {
                    checkHandling(5)
                    color = it.solidColor
                    toast(color.toString())
                }
            }
        }
    }

    private fun checkHandling(index: Int) {
        when (index) {
            1 -> {
                binding.icCheck1.visible()
                binding.icCheck2.hide()
                binding.icCheck3.hide()
                binding.icCheck4.hide()
                binding.icCheck5.hide()
            }
            2 -> {
                binding.icCheck1.hide()
                binding.icCheck2.visible()
                binding.icCheck3.hide()
                binding.icCheck4.hide()
                binding.icCheck5.hide()
            }
            3 -> {
                binding.icCheck1.hide()
                binding.icCheck2.hide()
                binding.icCheck3.visible()
                binding.icCheck4.hide()
                binding.icCheck5.hide()
            }
            4 -> {
                binding.icCheck1.hide()
                binding.icCheck2.hide()
                binding.icCheck3.hide()
                binding.icCheck4.visible()
                binding.icCheck5.hide()
            }
            5 -> {
                binding.icCheck1.hide()
                binding.icCheck2.hide()
                binding.icCheck3.hide()
                binding.icCheck4.hide()
                binding.icCheck5.visible()
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        _binding = null
    }
}