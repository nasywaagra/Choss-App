package com.project.chossapp.ui.shop

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.project.chossapp.R

class ShopActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_shop)
    }
}