package com.project.chossapp.util

object Dimen {
    const val PERSONALITY = "personality"
    const val CLOTH = "cloth"
}